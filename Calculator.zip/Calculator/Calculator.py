import tkinter as tk

def printInput():
    inp = inputtxt.get(1.0, "end-1c")
    dat = [char for char in inp]
    Num1 = int(dat[0])
    Num2 = int(dat[2])
    Operator = dat[1]
    if Operator == "+":
        lbl.config(fg="green", text=Num1 + Num2)
    elif Operator == "-":
        lbl.config(fg="green", text=Num1 - Num2)
    elif Operator == "*":
        lbl.config(fg="green", text=Num1 * Num2)
    else:
        lbl.config(fg="green", text=Num1 / Num2)

root = tk.Tk()  
root.title("Calculator")  
root.geometry("400x200")
root.config(bg="gray")

inputtxt = tk.Text(root, height=5, width=20)  
inputtxt.pack()

printButton = tk.Button(root, text="Calculate", command=printInput)  
printButton.pack()  

lbl = tk.Label(root, text="")  
lbl.pack()

while True:
    try:
        root.update()
    except tk.TclError:
        break



