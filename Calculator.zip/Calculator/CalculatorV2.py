import tkinter as tk
import re

# Global Variables
Digit_str = ""

# Functions
def Create_Digit_str(string):
    global Digit_str
    Digit_str = Digit_str + string
    CalcL.config(text=Digit_str)
    AnsL.config(text="")

def Calculate():
    global Digit_str
    Digits = Digit_str
    Digit_spl = re.split(r'(\W)', Digits)
    try:
        if Digit_spl[1] == "+":
            Ans = int(Digit_spl[0]) + int(Digit_spl[2])
            CalcL.config(text=(Digit_str, "="))
            AnsL.config(text=Ans)
            Digit_str = ""
        elif Digit_spl[1] == "-":
            Ans = int(Digit_spl[0]) - int(Digit_spl[2])
            CalcL.config(text=(Digit_str, "="))
            AnsL.config(text=Ans)
            Digit_str = ""
        elif Digit_spl[1] == "*":
            Ans = int(Digit_spl[0]) * int(Digit_spl[2])
            CalcL.config(text=(Digit_str, "="))
            AnsL.config(text=Ans)
            Digit_str = ""
        else: 
            Ans = int(Digit_spl[0]) / int(Digit_spl[2])
            CalcL.config(text=(Digit_str, "="))
            AnsL.config(text=Ans)
            Digit_str = ""
    except IndexError:
        print("Error: IndexError")

def Clear_str():
    global Digit_str
    Digit_str = ""
    AnsL.config(text="")

# Create main window
frame = tk.Tk()
frame.title("Calculator")
frame.geometry("450x600")
frame.iconbitmap("Calc.ico")

# Number Buttons
Ltitle = tk.Label(frame, text="CALCULATOR:")
Ltitle.place(x=0, y=0, width=100, height=50)

B0 = tk.Button(frame, text="0", command=lambda: Create_Digit_str("0"))
B0.place(x=100, y=500, width=100, height=100)

B1 = tk.Button(frame, text="1", command=lambda: Create_Digit_str("1"))
B1.place(x=0, y=400, width=100, height=100)

B2 = tk.Button(frame, text="2", command=lambda: Create_Digit_str("2"))
B2.place(x=100, y=400, width=100, height=100)

B3 = tk.Button(frame, text="3", command=lambda: Create_Digit_str("3"))
B3.place(x=200, y=400, width=100, height=100)

B4 = tk.Button(frame, text="4", command=lambda: Create_Digit_str("4"))
B4.place(x=0, y=300, width=100, height=100)

B5 = tk.Button(frame, text="5", command=lambda: Create_Digit_str("5"))
B5.place(x=100, y=300, width=100, height=100)

B6 = tk.Button(frame, text="6", command=lambda: Create_Digit_str("6"))
B6.place(x=200, y=300, width=100, height=100)

B7 = tk.Button(frame, text="7", command=lambda: Create_Digit_str("7"))
B7.place(x=0, y=200, width=100, height=100)

B8 = tk.Button(frame, text="8", command=lambda: Create_Digit_str("8"))
B8.place(x=100, y=200, width=100, height=100)

B9 = tk.Button(frame, text="9", command=lambda: Create_Digit_str("9"))
B9.place(x=200, y=200, width=100, height=100)

# Operators Buttons
BP = tk.Button(frame, text="+", command=lambda: Create_Digit_str("+"))
BP.place(x=300, y=200, width=100, height=100)

BS = tk.Button(frame, text="-", command=lambda: Create_Digit_str("-"))
BS.place(x=300, y=300, width=100, height=100)

BM = tk.Button(frame, text="X", command=lambda: Create_Digit_str("*"))
BM.place(x=300, y=400, width=100, height=100)

BD = tk.Button(frame, text="/", command=lambda: Create_Digit_str("/"))
BD.place(x=300, y=500, width=100, height=100)

# Other Options
BC = tk.Button(frame, text="CLEAR", command=Clear_str)
BC.place(x=0, y=500, width=100, height=100)

BE = tk.Button(frame, text="=", command=Calculate)
BE.place(x=200, y=500, width=100, height=100)

CalcL = tk.Label(frame, text="", font="bold 15")
CalcL.place(x=30, y=50, width=200, height=15)

AnsL = tk.Label(frame, text="", font="bold 20")
AnsL.place(x=30, y=70, width=200, height=20)

frame.mainloop()
